<?php

include_once BRUNN_CORE_CPT_PATH . '/portfolio/portfolio-register.php';
include_once BRUNN_CORE_CPT_PATH . '/portfolio/helper-functions.php';