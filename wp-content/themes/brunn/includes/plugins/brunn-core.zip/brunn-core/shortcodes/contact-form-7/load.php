<?php

include_once BRUNN_CORE_SHORTCODES_PATH . '/contact-form-7/functions.php';
