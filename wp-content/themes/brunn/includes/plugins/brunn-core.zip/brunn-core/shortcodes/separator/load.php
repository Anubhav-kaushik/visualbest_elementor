<?php

include_once BRUNN_CORE_SHORTCODES_PATH . '/separator/functions.php';
include_once BRUNN_CORE_SHORTCODES_PATH . '/separator/separator.php';