<?php

include_once BRUNN_CORE_SHORTCODES_PATH . '/process/functions.php';
include_once BRUNN_CORE_SHORTCODES_PATH . '/process/process.php';
include_once BRUNN_CORE_SHORTCODES_PATH . '/process/process-item.php';